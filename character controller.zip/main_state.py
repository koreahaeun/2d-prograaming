import random
import json
import os

from pico2d import *

import game_framework
import title_state



name = "MainState"
background = None
player1 = None
player2 = None
ground = None
font = None




name = "MainState"
background = None
player1 = None
player2 = None
ground = None
font = None
pl1hp = None
pl2hp = None
class pl1hp:
    def __init__(self):
        self.hp=250
        self.hpx=0
        self.image = load_image('pl1hp.png')
    def draw(self):
        self.image.clip_draw(self.hpx,0,self.hp,25,210,500)
    def update(self):
        if pl1.status==4:
            self.hpx+=30
class pl2hp:
    def __init__(self):
        self.hpx2=590
        self.hpw2=250
        self.image = load_image('pl1hp.png')
    def draw(self):
        self.image.draw(self.hpx2,500,self.hpw2,25)
class background:
    def __init__(self):
        self.image = load_image('background.png')
        self.image2 = load_image('ko.png')
    def draw(self):
        self.image.draw(400,300)
        self.image2.draw(404,500)

class ground:
    def __init__(self):
        self.image = load_image('ground2.png')

    def draw(self):
        self.image.draw(400, 100)


class player1:
    def __init__(self):
        self.x, self.y = 120, 150
        self.frame = 0
        self.status=0
        self.drawc=0

    def get_bb(self):
        return self.x-20, self.y-50, self.x+20, self.y+50
    def draw_bb(self):
        if self.drawc==1:
            draw_rectangle(*self.get_bb())

    def update(self):
        if self.status == 1:
            self.dash = load_image('dash.png')
            if pl1.x+30>=pl2.x2:
                self.x+=0
            else:
                self.x+=15
            if self.frame==3:
                self.status = 0
                self.frame =0
        if self.status == 2:
            self.punch = load_image('funching.png')
            if self.frame==6:
                self.status = 0
                self.frame = 0
        if self.status == 3:
            self.kick = load_image('kick.png')
            if self.frame==4:
                self.status = 0
                self.frame = 0
        if self.status == 4:
            self.touch = load_image('touch.png')
            self.x-=3
            if self.frame==2:
                self.status = 0
                self.frame = 0
        elif self.status == 0:
            self.image = load_image('waiting.png')
            if self.frame==2:
                self.status=0
                self.frame=0



    def draw(self):
        if self.status==1:
            self.dash.clip_draw(self.frame * 100, 0, 100, 100, self.x, self.y)
            self.frame+=1
        if self.status==2:
            self.punch.clip_draw(self.frame * 100, 0, 100, 100, self.x-3, self.y-5)
            self.frame+=1
        if self.status==3:
            self.kick.clip_draw(self.frame*100, 0, 100, 100, self.x-3, self.y-5)
            self.frame+=1
        if self.status==0:
            self.image.clip_draw(self.frame * 100, 0, 100, 100, self.x, self.y)
            self.frame+=1
        if self.status==4:
            self.touch.clip_draw(self.frame * 100,0, 100, 100, self.x, self.y)
            self.frame+=1

class player2:
    def __init__(self):
        self.x2, self.y2 = 680, 150
        self.frame2 = 0
        self.status2=0
        self.drawc2=0
    def get_bb(self):
        return self.x2-20, self.y2-50, self.x2+20, self.y2+50
    def draw_bb(self):
        if self.drawc2==1:
            draw_rectangle(*self.get_bb())

    def update(self):
        if self.status2 == 1:
            self.dash2 = load_image('dash2.png')
            if pl2.x2-30<=pl1.x:
                pl2.x2-=0
            else:
                self.x2-=15
            if self.frame2==3:
                self.status2 = 0
                self.frame2 =0
        if self.status2 == 2:
            self.punch2 = load_image('funching2.png')
            if self.frame2==6:
                self.status2 = 0
                self.frame2 = 0
        if self.status2 == 3:
            self.kick2 = load_image('kick2.png')
            if self.frame2==4:
                self.status2 = 0
                self.frame2 = 0
        if self.status2 == 4:
            self.touch2 = load_image('touch2.png')
            self.x2+=3
            if self.frame2==2:
                self.status2 = 0
                self.frame2 = 0
        elif self.status2 == 0:
            self.image2 = load_image('waiting2.png')
            if self.frame2==2:
                self.status2=0
                self.frame2=0

    def draw(self):
        if self.status2==1:
            self.dash2.clip_draw(self.frame2 * 100, 0, 100, 100, self.x2, self.y2)
            self.frame2+=1
        if self.status2==2:
            self.punch2.clip_draw(self.frame2 * 100, 0, 100, 100, self.x2+3, self.y2-5)
            self.frame2+=1
        if self.status2==3:
            self.kick2.clip_draw(self.frame2 * 100, 0, 100, 100, self.x2+3, self.y2-5)
            self.frame2+=1
        if self.status2==0:
            self.image2.clip_draw(self.frame2 * 100, 0, 100, 100, self.x2, self.y2)
            self.frame2+=1
        if self.status2==4:
            self.touch2.clip_draw(self.frame2 * 100,0, 100, 100, self.x2, self.y2)
            self.frame2+=1


def enter():
    global pl1,pl2, ground,bag,hp1,hp2
    bag=background()
    hp1=pl1hp()
    hp2=pl2hp()
    pl1 = player1()
    pl2 = player2()
    ground = ground()
    hide_lattice()

def collide(a, b):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = b.get_bb()

    if left_a > right_b : return False
    if right_a < left_b : return False
    if top_a < bottom_b : return False
    if bottom_a > top_b : return False

    return True

def exit():
    global pl1,pl2,ground,bag,hp1,hp2
    del(hp1)
    del(hp2)
    del(bag)
    del(pl2)
    del(pl1)
    del(ground)


def pause():
    pass

def resume():
    pass


def handle_events():

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        if event.type == SDL_KEYDOWN and event.key == SDLK_c:
            pl1.drawc+=1
            pl2.drawc2+=1
        if event.type == SDL_KEYUP and event.key == SDLK_c:
            pl1.drawc-=1
            pl2.drawc2-=1
        if event.type == SDL_KEYDOWN and event.key == SDLK_j:
            if pl1.x+30>=pl2.x2:
                pl1.x+=0
            else:
                pl1.x+=7
        elif event.type == SDL_KEYDOWN and event.key == SDLK_g:
            pl1.x-=7
        elif event.type == SDL_KEYDOWN and event.key == SDLK_d:
            pl1.status=1
            pl1.frame=0
        elif event.type == SDL_KEYDOWN and event.key == SDLK_a:
            if collide(pl1,pl2):
                pl2.status2=4
                pl2.frame2=0
                pl1.status=2
                pl1.frame=0
            else:
                pl1.status=2
                pl1.frame=0
        elif event.type == SDL_KEYDOWN and event.key == SDLK_s:
            if collide(pl1,pl2):
                pl2.status2=4
                pl2.frame2=0
                pl1.status=3
                pl1.frame=0
            else:
                pl1.status=3
                pl1.frame=0
        if event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT:
            pl2.x2+=7
        elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT:
            if pl2.x2-30<=pl1.x:
                pl2.x2-=0
            else:
                pl2.x2-=7
        elif event.type == SDL_KEYDOWN and event.key == SDLK_b:
            pl2.status2=1
            pl2.frame2=0
        elif event.type == SDL_KEYDOWN and event.key == SDLK_n:
            if collide(pl1,pl2):
                pl1.status=4
                pl1.frame=0
                pl2.status2=2
                pl2.frame2=0
            else:
                pl2.status2=2
                pl2.frame2=0
        elif event.type == SDL_KEYDOWN and event.key == SDLK_m:
            if collide(pl1,pl2):
                pl1.status=4
                pl1.frame=0
                pl2.status2=3
                pl2.frame2=0
            else:
                pl2.status2=3
                pl2.frame2=0


def update():
    pl1.update()
    pl2.update()
    hp1.update()
    delay(0.05)




def draw():
    clear_canvas()
    bag.draw()
    hp1.draw()
    hp2.draw()
    ground.draw()
    pl1.draw()
    pl2.draw()
    pl1.draw_bb()
    pl2.draw_bb()

    update_canvas()








