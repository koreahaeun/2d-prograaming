from pico2d import *
import math

def handle_events():
    global running
    global x
    global y
    global centerx
    global centery
    global length
    global horn
    global rad
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
        elif event.type == SDL_MOUSEMOTION:
            centerx= event.x
            centery= 600-event.y
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                running = False
            elif event.key == SDLK_UP:
                centery = centery + 100
            elif event.key == SDLK_DOWN:
                centery = centery - 100
            elif event.key == SDLK_LEFT:
                centerx = centerx - 100
            elif event.key == SDLK_RIGHT:
                centerx = centerx + 100
            elif event.key == SDLK_a:
                if(rad<=280):
                    rad = rad+20
            elif event.key == SDLK_d:
                if(rad>=40):
                    rad = rad-20
    # fill here



open_canvas()
grass = load_image('grass.png')
character = load_image('run_animation.png')

running = True
x=0
y=0
centerx = 400
centery = 300
frame = 0
rad = 100
horn = 0
length = 0
while (running):
    clear_canvas()
    grass.draw(400, 30)
    character.clip_draw(frame * 100, 0, 100, 100, centerx+math.sin(horn)*rad, centery-math.cos(horn)*rad)
    update_canvas()
    length = length +20
    horn = (length/180)*math.pi

    frame = (frame + 1) % 8
    delay(0.05)
    handle_events()

close_canvas()

