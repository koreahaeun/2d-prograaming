
from pico2d import *

name = "stickfighter"

def handle_events():
    global running
    global punching
    global dashing
    global dashing2
    global running2
    global kicking
    global x
    global y
    global x2
    global y2
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
            running2 = False
            punching = False
            dashing = False
            dashing2 = False
            kicking = False

        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                running = False
                running2 = False
                punching = False
                dashing = False
                dashing2 = False
                kicking = False
            elif event.key == SDLK_g:
                x = x - 10
            elif event.key == SDLK_j:
                x = x + 10
            elif event.key == SDLK_a:
                punching = True
            elif event.key == SDLK_s:
                kicking = True
            elif event.key == SDLK_d:
                dashing = True
            elif event.key == SDLK_LEFT:
                x2 = x2 - 10
            elif event.key == SDLK_RIGHT:
                x2 = x2 + 10
            elif event.key == SDLK_k:
                dashing2 = True

    # fill here



open_canvas()
grass = load_image('grass.png')
waiting = load_image('waiting.png')
funching = load_image('funching.png')
kick = load_image('kick.png')
dash = load_image('dash.png')
run2 = load_image('waiting2.png')
dash2 = load_image('dash2.png')



running = True
running2 = True
punching = False
kicking = False
dashing = False
dashing2 = False
punchc = 0
kickc = 0
dashc = 0
dashc2 = 0
x=50
x2=550
y=0
y2=0
frame = 0
frame1 = 0
while (running and running2):
    clear_canvas()
    grass.draw(400, 30)
    waiting.clip_draw(frame * 100, 0, 100, 100, x, 90)
    run2.clip_draw(frame*100,0,100,100,x2,90)
    update_canvas()
    while(kicking):
        clear_canvas()
        grass.draw(400,30)
        kick.clip_draw(frame * 100,0, 100,100, x, 85)
        update_canvas()
        kickc+=1
        frame = (frame +1) % 4
        delay(0.02)
        if kickc == 4:
            kicking = False
            kickc = 0
    while(punching):
        clear_canvas()
        grass.draw(400, 30)
        funching.clip_draw(frame * 100, 0, 100, 100, x, 85)
        run2.clip_draw(frame1*100,0,100,100,x2,90)
        update_canvas()
        punchc+=1
        frame = (frame + 1) % 6
        frame1 = (frame1 + 1) % 2
        delay(0.02)
        if punchc == 6:
            punching = False
            punchc = 0
    while(dashing):
        clear_canvas()
        grass.draw(400,30)
        dash.clip_draw(frame*100,0,100,100,x,85)
        run2.clip_draw(frame1*100,0,100,100,x2,90)
        update_canvas()
        dashc+=1
        x+=30
        frame = (frame +1) % 3
        frame = (frame1 +1) % 2
        delay(0.1)
        if dashc == 3:
            dashing = False
            dashc = 0
    while(dashing2):
        clear_canvas()
        grass.draw(400,30)
        dash2.clip_draw(frame * 100,0,100,100,x2,85)
        update_canvas()
        dashc2+=1
        x2-=30
        frame = (frame +1) % 3
        delay(0.5)
        if dashc2 == 3:
            dashing2 = False
            dashc2 = 0



    frame = (frame + 1) % 2
    delay(0.1)
    handle_events()

close_canvas()